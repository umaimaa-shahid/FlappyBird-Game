Commands: 

To Assemble: nasm fileName.asm -o fileName.com | nasm fileName.asm -o fileName.lst
OR           nasm ex01.asm -o ex01.com -l ex01.lst
To Execute: afd fileName.com

Mounts on its Own: ALT+R

Single line comment
Semicolon ( ; )

Multi - line comment 
ctrl + shift + q
 to comment 

alt + shift + z 
For uncomment

Alt + d for debugging 
Alt + r for video memory (not needed now)